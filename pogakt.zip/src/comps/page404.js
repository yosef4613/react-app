import React from 'react';
import PageHeader from './common/pageHeader';

function Page404(props){
  return(
    <div>
      <PageHeader title="Page not found , 404!" />
    </div> 
  )
}

export default Page404